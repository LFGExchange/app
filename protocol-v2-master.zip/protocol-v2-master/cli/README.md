## Installation
```shell
yarn &&
tsc &&
npm link &&
drift config init
```