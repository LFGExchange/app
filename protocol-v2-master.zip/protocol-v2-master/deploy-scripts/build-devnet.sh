#!/bin/sh
anchor build -- --no-default-features