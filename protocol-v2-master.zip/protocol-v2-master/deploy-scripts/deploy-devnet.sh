#!/bin/sh
anchor upgrade --program-id dRiftyHA39MWEi3m9aunc5MzRF1JYuBsbn6VPcn33UH --provider.cluster devnet --provider.wallet $SOLANA_PATH/$DEVNET_ADMIN target/deploy/drift.so